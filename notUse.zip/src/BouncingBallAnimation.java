import biuoop.GUI;
import biuoop.DrawSurface;
import biuoop.Sleeper;
import java.awt.Color;

/**
 * This class demonstrates a simple animation of bouncing balls and blocks using the Biuoop library.
 */
public class BouncingBallAnimation {

    /**
     * Main method to start the bouncing balls animation.
     * Creates a GUI window, initializes balls and blocks, and runs the animation loop.
     * Uses a Sleeper to control the animation timing.
     *
     * @param args command-line arguments (unused)
     */
    public static void main(String[] args) {
        // Initialize GUI and necessary components
        GUI gui = new GUI("Bouncing Balls Animation", 400, 400);
        Sleeper sleeper = new Sleeper();
        GameEnvironment gameEnvironment = new GameEnvironment();
        SpriteCollection spriteCollection = new SpriteCollection();

        // Create a blue ball and add it to the sprite collection
        Ball ball = new Ball(new Point(200, 200), 10, Color.BLUE, gameEnvironment);
        ball.setVelocity(0, 6);
        spriteCollection.addSprite(ball);

        // Create blocks and add them to the game environment and sprite collection
        Block block1 = new Block(new Point(50, 50), 300, 20);
        Block block2 = new Block(new Point(50, 100), 300, 20);
        Block block3 = new Block(new Point(50, 300), 300, 20);

        gameEnvironment.addCollidable(block1);
        gameEnvironment.addCollidable(block2);
        gameEnvironment.addCollidable(block3);

        spriteCollection.addSprite(block1);
        spriteCollection.addSprite(block2);
        spriteCollection.addSprite(block3);

        // Animation loop
        while (true) {
            DrawSurface surface = gui.getDrawSurface();
            spriteCollection.drawAllOn(surface); // Draw all sprites on the surface
            gui.show(surface); // Show the updated surface on the GUI
            spriteCollection.notifyAllTimePassed(); // Notify all sprites that time has passed
            sleeper.sleepFor(10); // Wait for 10 milliseconds before the next iteration
        }
    }
}
